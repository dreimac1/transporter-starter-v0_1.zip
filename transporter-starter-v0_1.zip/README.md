# Transporter Starter Monorepo (v0.1)
This is an MVP scaffold for the Transporter platform.

- `backend/` Node.js (TypeScript) + Express + Prisma + PostgreSQL + Socket.IO
- `admin/` React (Vite) TypeScript shell for the Admin dashboard
- `apps/rider/` React Native (Expo) placeholder
- `apps/customer/` React Native (Expo) placeholder

## Quick start (backend)
1. Copy `.env.example` to `.env` and fill values.
2. `cd backend && npm install`
3. `npx prisma migrate dev`
4. `npm run dev`

> Note: Frontends are placeholders to be expanded next.
