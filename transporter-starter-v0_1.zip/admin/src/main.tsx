import React from 'react';
import { createRoot } from 'react-dom/client';

function App(){
  return (<div style={{padding:20}}>
    <h1>Transporter Admin</h1>
    <p>Welcome. Replace this with Next.js or keep Vite for MVP.</p>
    <ul>
      <li>KYC queue</li>
      <li>Deliveries</li>
      <li>Reports & CSV export</li>
    </ul>
  </div>);
}

createRoot(document.getElementById('root')!).render(<App/>);
