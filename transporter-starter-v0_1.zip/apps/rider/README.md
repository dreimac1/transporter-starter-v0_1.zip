# Rider App (Expo placeholder)

Initialize with `npx create-expo-app` and wire API base URL via `.env`.
