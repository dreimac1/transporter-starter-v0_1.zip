import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { createServer } from 'http';
import { Server } from 'socket.io';
import authRouter from './routes/auth.js';
import riderRouter from './routes/rider.js';
import customerRouter from './routes/customer.js';

const app = express();
const logger = pino();
app.use(pinoHttp({ logger }));
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || true }));
app.use(express.json({ limit: '5mb' }));

app.get('/health', (_req, res) => res.json({ ok: true, time: new Date().toISOString() }));
app.use('/auth', authRouter);
app.use('/rider', riderRouter);
app.use('/customer', customerRouter);

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: process.env.CORS_ORIGIN?.split(',') || true } });

io.on('connection', socket => {
  socket.on('rider:status', (payload) => {
    // TODO: update presence / location
    socket.join(`rider:${payload.riderId}`);
  });
});

const port = process.env.PORT || 8080;
httpServer.listen(port, () => logger.info({ msg: 'API up', port }));
