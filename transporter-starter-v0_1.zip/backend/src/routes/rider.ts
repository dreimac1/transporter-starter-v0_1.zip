import { Router } from 'express';
const router = Router();

router.get('/me', (_req, res) => {
  // TODO: get rider profile
  res.json({ rider: { id: 'rider-id', primeLevel: 'NONE' } });
});

router.get('/jobs-feed', (_req, res) => {
  // TODO: list nearby jobs sorted by score
  res.json({ jobs: [] });
});

router.post('/jobs/:id/accept', (req, res) => {
  // TODO: accept job atomically
  res.json({ ok: true });
});

export default router;
