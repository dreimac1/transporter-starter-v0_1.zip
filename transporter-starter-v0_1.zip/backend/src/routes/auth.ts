import { Router } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { z } from 'zod';

const router = Router();
const secret = process.env.JWT_SECRET || 'dev';

const RegisterSchema = z.object({
  phone: z.string().min(8),
  role: z.enum(['RIDER','CUSTOMER']).default('CUSTOMER'),
  password: z.string().min(6)
});

router.post('/register', async (req, res) => {
  const parse = RegisterSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.format() });
  // TODO: create user in DB (Prisma)
  const token = jwt.sign({ sub: 'user-id', role: parse.data.role }, secret, { expiresIn: '7d' });
  res.json({ token });
});

const LoginSchema = z.object({ phone: z.string(), password: z.string() });
router.post('/login', async (req, res) => {
  const parse = LoginSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.format() });
  // TODO: check user + password
  const token = jwt.sign({ sub: 'user-id', role: 'CUSTOMER' }, secret, { expiresIn: '7d' });
  res.json({ token });
});

export default router;
