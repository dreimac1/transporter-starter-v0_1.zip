import { Router } from 'express';
import { z } from 'zod';
const router = Router();

const QuoteSchema = z.object({
  pickup: z.object({ lat: z.number(), lng: z.number() }),
  dropoff: z.object({ lat: z.number(), lng: z.number() }),
  km: z.number().min(0.1)
});

router.post('/quote', (req, res) => {
  const parse = QuoteSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });
  const base = 500; // NGN
  const perKm = 120; // NGN per km
  const price = Math.round(base + perKm * parse.data.km);
  res.json({ price });
});

export default router;
